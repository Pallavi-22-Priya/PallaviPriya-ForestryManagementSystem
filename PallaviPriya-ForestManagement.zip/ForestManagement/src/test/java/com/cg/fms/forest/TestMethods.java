package com.cg.fms.forest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.util.List;

import org.junit.Test;

import com.cg.fms.dao.CustomerDao;
import com.cg.fms.dao.ICustomerDao;
import com.cg.fms.dto.Customer;
import com.cg.fms.exception.CustomerException;
import com.cg.fms.service.CustomerService;
import com.cg.fms.service.ICustomerService;

public class TestMethods {
	ICustomerService Ics =new CustomerService();
	@Test
	public void serviceAddCustomerTest()
	{
	Customer customer=new Customer("Clo134","Pallu","pallu@gmail.com","Pallu@09","524416","Muttembakas","Nellore","1234567890");
	
	Customer customers=Ics.serviceAddCustomer(customer);
	assertEquals("Clo134",customers.getCustomerId());
	assertEquals("Pallavi",customers.getCustomerName());
	assertEquals("pallavi@gmail.com",customers.getCustomerEmail());
	assertEquals("Pallavi@09",customers.getCustomerPassword());
	assertEquals("524415",customers.getCustomerPostalcode());
	assertEquals("Muttembaka",customers.getCustomerAddress());
	assertEquals("Gudur",customers.getCustomerTown());
	assertEquals("1234567890",customers.getCustomerContact());
	}
	@Test
	public void serviceGetAllCustomersTest()
	{
		List<Customer> list=Ics.serviceGetAllCustomers();
		int size;
		size=list.size();
		assertTrue(size>=2);		
		assertFalse(size<3);
		assertNotNull(size);
	}
	@Test
	public void serviceGetCustomerTest() throws CustomerException
	{
		Customer customer=Ics.serviceGetCustomer("Clo129");
		Customer c1=Ics.serviceGetCustomer("Clo129");
	assertEquals(customer,c1);
	assertEquals(customer.getCustomerId(),c1.getCustomerId());
		assertSame(customer, c1);
	}
	@Test
	public void serviceUpdateCustomerTest() throws CustomerException
	{
		Customer customer=new Customer("Clo129","PallaviPriya","pallavipriya@gmail.com","Pallavi@09","524415","Gudur","Nellore","1235678904");
		Customer c=new Customer("Clo129","Pallu","","","","","",""); 
		
		Customer customers=Ics.serviceUpdateCustomer(customer);
		assertEquals(customer.getCustomerId(),c.getCustomerName());
		
	}
	@Test
	public void serviceDeleteCustomerTest() throws CustomerException
	{
		Customer customers=Ics.serviceDeleteCustomer("Clo133");
		Customer c2=Ics.serviceDeleteCustomer("Clo133");
		assertNotEquals(customers,c2);
		assertNotNull(customers);
		assertNotNull(c2);
		
	}
	
}
