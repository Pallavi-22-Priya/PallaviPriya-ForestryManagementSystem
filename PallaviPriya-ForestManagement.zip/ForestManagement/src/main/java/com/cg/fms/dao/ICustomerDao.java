package com.cg.fms.dao;

import java.util.List;

import com.cg.fms.dto.Customer;
import com.cg.fms.exception.CustomerException;

public interface ICustomerDao {

	
//-----------------------------------------------------------Customer Module------------------------------------------------//
	/*************************************************************************************************************************
	 * -Function Name       :  serviceAddCustomer(Customer customer)
	 * Input Parameters     :    Customer customer
	 * Return type          :    Customer
	 * Author               :    Pallavi Priya
	 * Creation Date        :    27/10/2020
	 * Description          :    Adding customer details and returns the customer.
	 **************************************************************************************************************************/
	public Customer serviceAddCustomer(Customer customer);
	//--------------------------------------------------------Customer Module----------------------------------------------------------------//
	/***************************************************************************************************************************
	 * Function Name        :  serviveUpdate(Customer customer)
	 * Input Parameters     :  Customer customer
	 * Return type          :  Customer
	 * Author               :  Pallavi Priya
	 * Creation Date        :  27/10/2020
	 * Description          :  Updating the customer details
	 * ***************************************************************************************************************************/
	 
	 public Customer serviceUpdateCustomer(Customer customer)throws CustomerException;
	 //--------------------------------------------------------Customer Module------------------------------------------------------------------//
	 /**************************************************************************************************************************
	  * Function Name      :  serviceDelete(String customerId)
	  * Input Parameters   :  String customerId
	  * Return type        :  String
	  * Author             : Pallavi Priya
	  * Creation Date      : 27/10/2020
	  * Description        :Deleting the customer details
	  * **************************************************************************************************************************/

	public Customer serviceDeleteCustomer(String customerId)throws CustomerException;
	//--------------------------------------------------------Customer Module------------------------------------------------------------------//
		 /**************************************************************************************************************************
		  * Function Name      :  serviceGet(String customerId)
		  * Input Parameters   :  String customerId
		  * Return type        :  String
		  * Author             : Pallavi Priya
		  * Creation Date      : 27/10/2020
		  * Description        :Get  the customer details of the given Id
		  * **************************************************************************************************************************/


	public Customer serviceGetCustomer(String customerId)throws CustomerException;
	
	
	//-----------------------------------------------------------Customer Module---------------------------------------------------------------//
		 /**************************************************************************************************************************
		  * Function Name      :  serviceDelete(String customerId)
		  * Input Parameters   :  String customerId
		  * Return type        :  String
		  * Author             : Pallavi Priya
		  * Creation Date      : 27/10/2020
		  * Description        :Get All the customer details.
		  * **************************************************************************************************************************/

	
	public List<Customer> serviceGetAllCustomers();

	

	
	

}
