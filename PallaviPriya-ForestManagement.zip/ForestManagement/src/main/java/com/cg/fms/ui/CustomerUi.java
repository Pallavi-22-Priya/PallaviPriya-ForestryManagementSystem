package com.cg.fms.ui;

import java.util.*;

import com.cg.fms.dto.Customer;
import com.cg.fms.exception.CustomerException;
import com.cg.fms.service.CustomerService;
import com.cg.fms.service.ICustomerService;
import com.cg.fms.utility.Validations;

public class CustomerUi {
	public static void main(String[] args)
	
	{
		
		Scanner sc=new Scanner(System.in);
		ICustomerService Ics=new CustomerService();
		Validations v=new Validations();
		while(true)
		{
			System.out.println("Enter your choice :");
			System.out.println("1.Get a  Customer details");
			System.out.println("2.Add all the Customer details:");
			System.out.println("3. Update the Customer Details:");
			System.out.println("4.Delete the Customer Details:");
			System.out.println("5.Get all the Customer Details:");
			
			int choice=sc.nextInt();
			switch(choice)
			{
		case 1:
			System.out.println("ENter the customerId that you want to display");
			String  customerId=sc.next();
			while(true)
			{
			if(v.validateId(customerId))
				break;
			else
			{
				System.out.println("Please enter the customerId: with atleast 4 letters");
				 customerId=sc.next();
				
			  }
			 	
			}
			 try
			 {
			
			 System.out.println(Ics.serviceGetCustomer(customerId));
			 }
			 catch(CustomerException e)
			 {
				 System.out.println(e.getMessage());
			 }
			
			
			break;
					
		case 2:
			System.out.println("Enter the customerId:");
			 customerId=sc.next();
			while(true)
			{
				if(v.validateId(customerId))
					break;
				else
				{
					System.out.println("Please enter the customerId: with atleast 4 letters");
					 customerId=sc.next();
					
				}
			}
			System.out.println("Enter the customer Name:");
			String customerName=sc.next();
			while(true)
			{
				if(v.validateName(customerName))
					break;
				else
				{
					System.out.println("Please enter the customerId: with atleast 4 letters");
					 customerName=sc.next();
				}
			}
			System.out.println("Enter the customer email:");
			String customerEmail=sc.next();
			while(true)
			{
				if(v.validateEmail(customerEmail))
					break;
				else
				{
					System.out.println("Please enter the email with the given condtions");
					customerEmail=sc.next();
				}
			}
			
			System.out.println("Enter the customer Password:");
			String customerPassword=sc.next();
			while(true)
			{
				if(v.validatePassword(customerPassword))
					break;
				else
				{
					System.out.println("Please enter the customerPassword with  given condition");
					 customerPassword=sc.next();
				}
			}
			System.out.println("Enter the customer PostalCode");
			String customerPostalcode=sc.next();
			while(true)
			{
			if(v.validatePostalcode(customerPostalcode))
				break;
			else
			{
				System.out.println("Please enter the customerPostalCode  6 letters");
				 customerPostalcode=sc.next();
			}
			}
			System.out.println("Enter the customerAddress:");
			String customerAddress=sc.next();
			System.out.println("Enter the customer Town:");
			String customerTown=sc.next();
			System.out.println("Enter the customer Contact:");
			String customerContact=sc.next();
			while(true)
			{
				if(v.validateContact(customerContact))
					break;
				else
				{
					System.out.println("Please enter the customerContact: with  10 number");
					 customerContact=sc.next();
				}
			}
			Customer customer=new Customer(customerId,customerName,customerEmail,customerPassword,customerPostalcode,customerAddress,customerTown,customerContact);
				System.out.println(Ics.serviceAddCustomer(customer));
			System.out.println("Customer details are added successfully:");	
			break;
		case 3:
				System.out.println("Enter the customer Id:");
				  customerId=sc.next();
				  while(true)
					{
					if(v.validateId(customerId))
						break;
					else
					{
						System.out.println("Please enter the customerId: with atleast 4 letters");
						 customerId=sc.next();
						
					  }
					 	
					}
				 System.out.println("Enter the customer Name:");
				 customerName=sc.next();
				 while(true)
					{
						if(v.validateName(customerName))
							break;
						else
						{
							System.out.println("Please enter the customerId: with atleast 4 letters");
							 customerName=sc.next();
						}
					}
				 System.out.println("Enter the Customer Address:");
				 customerAddress=sc.next();
				 
				 System.out.println("Enter the Customer Email:");
				 customerEmail=sc.next();
				 while(true)
					{
						if(v.validateEmail(customerEmail))
							break;
						else
						{
							System.out.println("Please enter the email with the given condtions");
							customerEmail=sc.next();
						}
					}
				 System.out.println("Enter the Customer PostalCode");
				 customerPostalcode=sc.next();
				 while(true)
				 {
					 if(v.validatePostalcode(customerPostalcode))
						break;
						else
						{
							System.out.println("Please enter the Postalcode with the given condtions");
							customerPostalcode=sc.next();
						}
				 }
				
				 System.out.println("Enter the Customer Town:");
				 customerTown=sc.next();
				  Customer customers=new Customer();
				customers.setCustomerId(customerId);
				customers.setCustomerName(customerName);
				customers.setCustomerAddress(customerAddress);
				customers.setCustomerEmail(customerEmail);
				customers.setCustomerTown(customerTown);
				
				try
				{
					System.out.println(Ics.serviceUpdateCustomer(customers));
				}
				catch(CustomerException e)
				{
					System.out.println(e);
				}
				break;
			case 4:
				System.out.println("Enter the id  that you wnat to remove:");
				customerId=sc.next();
				 while(true)
					{
					if(v.validateId(customerId))
						break;
					else
					{
						System.out.println("Please enter the customerId: with atleast 4 letters");
						 customerId=sc.next();
						
					  }
					 	
					}
				try
				{
					System.out.println(Ics.serviceDeleteCustomer(customerId));
				}
				catch(CustomerException e)
				{
					System.out.println(e.getMessage());
				}
				break;
				
			case 5:
				
				
					List<Customer> lists=Ics.serviceGetAllCustomers();
					if(lists.size()!=0)
					{
						for(Customer custome:lists)
						{
							System.out.println(custome);
						}
					}
					else
					{
						System.out.println("NO details are found");
						break;
					}
			
			
			}
		}
	}
}
		
	
