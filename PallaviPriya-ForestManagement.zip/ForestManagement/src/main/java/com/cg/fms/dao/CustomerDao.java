package com.cg.fms.dao;




import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;


import com.cg.fms.dto.Customer;
import com.cg.fms.exception.CustomerException;
import com.cg.fms.utility.CustomerUtility;

public class CustomerDao implements ICustomerDao {

	EntityManagerFactory factory = null;
	EntityManager manager = null;
	EntityTransaction transaction= null;
	
	

	public Customer serviceAddCustomer(Customer customer) {
		
		factory=CustomerUtility.getFactory();
		manager= factory.createEntityManager();
		 transaction = manager.getTransaction();
		 transaction.begin();
		 manager.persist(customer);
		 transaction.commit();
		 
		return customer;
		
		
		
		
	}
	
	public Customer serviceUpdateCustomer(Customer customer) throws CustomerException{
		
		factory=CustomerUtility.getFactory();
		manager= factory.createEntityManager();
		 transaction = manager.getTransaction();
		 transaction.begin();
		 Customer customerRecord=manager.find(Customer.class,customer.customerId);
		if(customerRecord==null)
		
			throw new CustomerException("customer details are not found");
		else
		{
			customer.setCustomerName(customer.customerName);
			customer.setCustomerAddress(customer.customerAddress);
			customer.setCustomerPostalcode(customer.customerPostalcode);
			customer.setCustomerEmail(customer.customerEmail);
			customer.setCustomerTown(customer.customerTown);
			
			transaction.commit();
			
			
		}
		return customer;	
		
	}

	
	public Customer serviceDeleteCustomer(String customerId) throws CustomerException{
	
		factory=CustomerUtility.getFactory();
		manager= factory.createEntityManager();
		transaction = manager.getTransaction();
		transaction.begin();
		Customer customer=manager.find(Customer.class,customerId);
		if(customer==null)
			throw new CustomerException("customer deatils are not found with the given id:");
		else
		{
			manager.remove(customer);
			transaction.commit();
			
		}
		return customer;
		
	}

	
	public Customer serviceGetCustomer(String customerId) throws CustomerException {
		factory=CustomerUtility.getFactory();
		manager= factory.createEntityManager();
		Customer customer=manager.find(Customer.class,customerId);
		if(customer==null)
			throw new CustomerException("Customer not found with the given id:");
		
		return customer;
	}
	

	public List<Customer> serviceGetAllCustomers(){
		
		factory=CustomerUtility.getFactory();
		manager= factory.createEntityManager();
		String selectQuery="select e from Customer e ";
		Query query=manager.createQuery(selectQuery);
		@SuppressWarnings("unchecked")
		List<Customer> list=  query.getResultList();
		System.out.println(list);
		
		return list;
	}
	
		
	
	
	
	

}
