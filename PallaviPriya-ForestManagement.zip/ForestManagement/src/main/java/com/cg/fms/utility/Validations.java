package com.cg.fms.utility;

public class Validations {
	 
	//valiadteId checks  whether the given  id matches the  conditions are not///
	 	 public boolean validateId(String id)
	 	 {
	 		 String a="[a-zA-z0-9]{4,}";
	 		 if(id.matches(a))
	 			 return true;
	 		 else
	 			 return false;
	 	 }
//ValidateName  checks whether the given Name matches the conditions are not//
	 	 public boolean validateName(String name)
	 	 {
	 		 String a="[A-za-z]{4,}+";
	 		 if(name.matches(a))
	 			 return true;
	 		 else
	 			 return false;
	 	 }
/*validateEmail checks whether the given Email matches the conditions are not */
	 	 public boolean validateEmail(String email)
	 	 {
	 		 String a="[A-za-z0-9!@#$%^&*]+[@]+[a-z]+[.]+com";
	 		 if(email.matches(a))
	 			 return true;
	 		 else
	 			 return false;
	 	 }
/*validatePassword checks whether the given Password matches the conditions are not*/
	 	 public boolean validatePassword(String password)
	 	 {
	 		 String a="[A-za-z0-9@#$%^&*!]+";
	 		 if(password.matches(a))
	 			 return true;
	 		 else
	 			 return false;
	 	 }
/* validate Postalcode checks whether the  given Postalcode matches the condition are not*/
	 	 public boolean validatePostalcode(String Postalcode)
	 	 {
	 		 String a="[0-9]{6}+";
	 		 if(Postalcode.matches(a))
	 			 return true;
	 		 else
	 			 return false;
	 	 }
/*validate Contact  checks whether the given  Contact matches the condition are not*/
	 	 public boolean validateContact(String  Contact)
	 	 {
	 		 String a="[0-9]{10}";
	 		 if(Contact.matches(a))
	 			 return true;
	 		 else
	 			 return false;
	 	 }
	 	
	 }


