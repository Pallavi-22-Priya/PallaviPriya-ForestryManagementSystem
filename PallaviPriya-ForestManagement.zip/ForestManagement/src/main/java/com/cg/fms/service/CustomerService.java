package com.cg.fms.service;

import java.util.List;

import com.cg.fms.dao.CustomerDao;
import com.cg.fms.dao.ICustomerDao;
import com.cg.fms.dto.Customer;
import com.cg.fms.exception.CustomerException;
import com.cg.fms.utility.Validations;

public class CustomerService implements ICustomerService {
			 ICustomerDao icdao= new CustomerDao();
			
			
			 
	public Customer serviceGetCustomer(String customerId)throws CustomerException {
		
		return icdao.serviceGetCustomer(customerId);
	}

	public Customer serviceAddCustomer(Customer customer) {
		
			return icdao.serviceAddCustomer(customer);
			
	}
		
	


	public Customer serviceUpdateCustomer(Customer customer)throws CustomerException {
		return icdao.serviceUpdateCustomer(customer);
	}


	public Customer serviceDeleteCustomer(String customerId)throws CustomerException {
		
		return icdao.serviceDeleteCustomer(customerId);
	}

	
	public List<Customer> serviceGetAllCustomers() {
		
		return  icdao.serviceGetAllCustomers();
	}
	
}
