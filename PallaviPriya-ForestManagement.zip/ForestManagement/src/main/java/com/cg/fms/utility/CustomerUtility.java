package com.cg.fms.utility;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class CustomerUtility {


static EntityManagerFactory factory=null;
public static EntityManagerFactory getFactory() {
	if(factory==null)
	{
		factory=Persistence.createEntityManagerFactory("EMP_BU");
		
	}
	return factory;
}

}