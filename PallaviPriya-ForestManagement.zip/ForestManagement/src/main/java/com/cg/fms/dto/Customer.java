package com.cg.fms.dto;
import javax.persistence.*;


@Entity
public class Customer{

	@Id
	public String customerId;

public String customerName;
public String customerEmail;
public String customerPassword;
public String customerPostalcode;
public String customerAddress;
public String customerTown;
public String customerContact;

public Customer()
{
//default constructor	
}

public Customer(String customerId,String customerName,String customerEmail,String customerPassword,String customerPostalcode,String customerAddress,String customerTown,String customerContact )
{
	
	this.customerId=customerId;
	this.customerName=customerName;
	this.customerEmail=customerEmail;
	this.customerPassword=customerPassword;
	this.customerPostalcode=customerPostalcode;
	this.customerAddress=customerAddress;
	this.customerTown=customerTown;
	this.customerContact=customerContact;
	
}
public Customer(String customerName,String customerEmail,String customerPassword,String customerPostalcode,String customerAddress,String customerTown,String customerContact )
{
	
	this.customerName=customerName;
	this.customerEmail=customerEmail;
	this.customerPassword=customerPassword;
	this.customerPostalcode=customerPostalcode;
	this.customerAddress=customerAddress;
	this.customerTown=customerTown;
	this.customerContact=customerContact;
}
public String getCustomerId() {
	return customerId;
}
public void setCustomerId(String customerId) {
	this.customerId = customerId;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getCustomerEmail() {
	return customerEmail;
}
public void setCustomerEmail(String customerEmail) {
	this.customerEmail = customerEmail;
}
public String getCustomerPassword() {
	return customerPassword;
}
public void setCustomerPassword(String customerPassword) {
	this.customerPassword = customerPassword;
}
public String getCustomerPostalcode() {
	return customerPostalcode;
}
public void setCustomerPostalcode(String customerPostalcode) {
	this.customerPostalcode = customerPostalcode;
}
public String getCustomerAddress() {
	return customerAddress;
}
public void setCustomerAddress(String customerAddress) {
	this.customerAddress = customerAddress;
}
public String getCustomerTown() {
	return customerTown;
}
public void setCustomerTown(String customerTown) {
	this.customerTown = customerTown;
}
public String getCustomerContact()
{
	return customerContact;
}
public void setCustomerContact(String customerContact)
{
	this.customerContact=customerContact;
}


@Override
public String toString() {
	return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerEmail=" + customerEmail
			+ ", customerPassword=" + customerPassword + ", customerPostalcode=" + customerPostalcode
			+ ", customerAddress=" + customerAddress + ", customerTown=" + customerTown + ",customerContact=" +customerContact+"]";
}





}
